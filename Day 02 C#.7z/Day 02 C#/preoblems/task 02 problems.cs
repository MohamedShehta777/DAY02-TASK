﻿/* day 02 >> Part 01>>
problem 01 : 
// هذا الكود يُظهر كيفية جمع رقمين وإظهار الناتج في وحدة التحكم
int x = 10; // تعريف المتغير x وتعيين قيمته بـ 10
int y = 20; // تعريف المتغير y وتعيين قيمته بـ 20

/* 
   حساب مجموع المتغيرين x و y 
   وتخزين الناتج في متغير جديد يسمى sum
*/
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices.JavaScript;
using static System.Formats.Asn1.AsnWriter;

int sum = x + y;

// طباعة ناتج الجمع إلى وحدة التحكم
Console.WriteLine(sum); // من المتوقع طباعة 30

// question : 
//To comment a block of code:
// Press Ctrl +K >> Ctrl + C.
//To uncomment a block of code:
//Press Ctrl + K, Ctrl + U.
//----------------------------------------------------------------------------------------//

// problem 02 :

int x = 10; // Correcting the type by assigning an integer value
int y = 5; // Declare y and assign a value for the addition

Console.WriteLine(x + y); // Correct method call to output the sum (x + y)

// question :
//Runtime errors are mistakes that happen during the execution of the program and cause it to crash.
//Logical errors are mistakes in the program's logic that cause it to produce incorrect results without crashing.
//-----------------------------------------------------------------------------------------//

//problem 03 : 
string fullName = "John Doe";           
int age = 25;                          
decimal monthlySalary = 5000.00m;
bool isStudent = false;
//  question : 
//Readability - Consistency - Code Organization - Collaboration- Conformity to .NET Standards
//------------------------------------------------------------------------------------// 

// problem04 : 
using System;

class Program
{
    class Person
    {
        public string Name { get; set; }
    }

    static void Main()
    {
        // Create an instance of Person and assign it to 'person1'
        Person person1 = new Person { Name = "Alice" };

        // Assign 'person2' to refer to the same object as 'person1'
        Person person2 = person1;

        // Modify the Name property through 'person2'
        person2.Name = "Bob";

        // Both 'person1' and 'person2' now point to the same object, 
        // so changes through one reference affect the other.
        Console.WriteLine("Person 1's Name: " + person1.Name); // Output: Bob
        Console.WriteLine("Person 2's Name: " + person2.Name); // Output: Bob
    }
}
// question : 
//Memory Location: Value types are stored in the stack, and reference types are stored in the heap. 
//Copying Behavior: Value types copy the actual value when assigned to a new variable. Reference types copy the reference (address) to the object, meaning both variables point to the same object.
//-------------------------------------------------------------------------------------------------------------//

//problem 05: 
using System;

class Program
{
    static void Main()
    {
        // Declare variables
        int x = 15;
        int y = 4;

        // Calculate sum, difference, product, division result, and remainder
        int sum = x + y;
        int difference = x - y;
        int product = x * y;
        int divisionResult = x / y;       // This performs integer division
        int remainder = x % y;            // This gives the remainder of the division

        // Output the results
        Console.WriteLine("Sum: " + sum);              // Output: 19
        Console.WriteLine("Difference: " + difference); // Output: 11
        Console.WriteLine("Product: " + product);       // Output: 60
        Console.WriteLine("Division result: " + divisionResult); // Output: 3 (integer division)
        Console.WriteLine("Remainder: " + remainder);   // Output: 3 (remainder of 15 / 4)
    }
}


//question: 
//2 ÷ 7 = 0 remainder 2

//------------------------------------------------------------------------------------// 

//problem06: 
using System;

class Program
{
    static void Main()
    {
        // Input number
        int number = 14; // You can change this number to test other cases

        // Check if number is greater than 10 and even
        if (number > 10 && number % 2 == 0)
        {
            Console.WriteLine("The number is greater than 10 and even.");
        }
        else
        {
            Console.WriteLine("The number is either not greater than 10 or not even.");
        }
    }
}
// question : 
//Short - Circuiting: && short - circuits(stops evaluating the second condition if the first is false), while &always evaluates both sides.
//Data Type: && works with Boolean expressions, while & works with integer values (and can also be used with Boolean values but does not short-circuit).
//Bitwise Operations: & is used for bitwise operations (i.e., comparing bits), while && is for logical comparisons (true/false values).

//---------------------------------------------------------------------------------------------------// 
//problem07: 
using System;

class Program
{
    static void Main()
    {
        // Take double input from the user
        Console.Write("Enter a double value: ");
        double userInput = Convert.ToDouble(Console.ReadLine());

        // Implicit casting (not possible for double to int, this will give an error)
        // int implicitCast = userInput; // This will cause a compilation error

        // Explicit casting
        int explicitCast = (int)userInput;

        // Display the results
        Console.WriteLine("Original double value: " + userInput);
        Console.WriteLine("Explicitly casted to int: " + explicitCast);
    }
}
// question: 
//Loss of Precision
//Compiler Safety  
//example : 
int number = 15;
double result = number;  // Implicit casting, no loss of data
//---------------------------------------------------------------------------------------//
//problem08:
using System;

class Program
{
    static void Main()
    {
        // Prompt the user to enter their age as a string
        Console.Write("Enter your age: ");
        string ageInput = Console.ReadLine();

        try
        {
            // Convert the input string to an integer using Parse
            int age = int.Parse(ageInput);

            // Check if the age is valid (greater than 0)
            if (age > 0)
            {
                Console.WriteLine("Your age is: " + age);
            }
            else
            {
                Console.WriteLine("Please enter a valid age greater than 0.");
            }
        }
        catch (FormatException)
        {
            // Handle invalid format (e.g., non-numeric input)
            Console.WriteLine("Invalid input. Please enter a valid number for age.");
        }
        catch (OverflowException)
        {
            // Handle overflow if the number is too large or too small
            Console.WriteLine("The number entered is too large or too small.");
        }
    }
}
// question : 
//FormatException
//OverflowException
//How to Handle Exceptions:
//try-catch Block
//-------------------------------------------------------------------------------------//
//problem 09:
using System;

class Program
{
    static void Main()
    {
        // Initialize variable x
        int x = 5;

        // Demonstrating prefix and postfix increment operators
        int prefixResult = ++x;  // Prefix increment: x is incremented first, then assigned
        Console.WriteLine("After prefix increment, x = " + x);  // Output: 6
        Console.WriteLine("Prefix result: " + prefixResult);  // Output: 6

        // Reset x to 5 again for clarity
        x = 5;

        // Postfix increment: x is used first, then incremented
        int postfixResult = x++;  // Postfix increment: x is assigned first, then incremented
        Console.WriteLine("After postfix increment, x = " + x);  // Output: 6
        Console.WriteLine("Postfix result: " + postfixResult);  // Output: 5
    }
}
// question :
int x = 5;
int y = ++x + x++;

y = 6(from++x) + 6(from x++)
y = 12






